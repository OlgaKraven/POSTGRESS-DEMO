﻿using DairyDemo.Auth.UI.Controls;

namespace DairyDemo.Auth.UI.Forms
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SuspendLayout();
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "LoginForm";
            Text = "LoginForm";
            Load += LoginForm_Load;
            ResumeLayout(false);

            var captcha = new CaptchaPuzzleControl
            {
                Left = 260,
                Top = 40
            };

            Controls.Add(captcha);

            captcha.LoadFromFolder(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "captcha")
            );

        }

        #endregion
        private void LoginForm_Load(object sender, EventArgs e)
        {
            // Логика не обязательна
            // Можно оставить пустым
        }

    }
}