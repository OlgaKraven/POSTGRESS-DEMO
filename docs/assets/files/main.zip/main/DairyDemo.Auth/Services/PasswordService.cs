﻿namespace DairyDemo.Auth.Services;

public sealed class PasswordService
{
    public string HashPassword(string password)
        => BCrypt.Net.BCrypt.HashPassword(password);

    public bool Verify(string password, string hash)
    {
        if (string.IsNullOrWhiteSpace(hash))
            return false;

        // BCrypt хэши обычно начинаются с $2a$, $2b$, $2y$
        if (!hash.StartsWith("$2"))
            return false;

        try
        {
            return BCrypt.Net.BCrypt.Verify(password, hash);
        }
        catch (BCrypt.Net.SaltParseException)
        {
            // В базе лежит строка не формата BCrypt
            return false;
        }
        catch
        {
            // Любая другая непредвиденная ошибка - тоже трактуем как неверный пароль
            return false;
        }
    }
}
