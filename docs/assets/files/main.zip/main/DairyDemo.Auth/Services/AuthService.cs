﻿using DairyDemo.Auth.Data.Repositories;
using DairyDemo.Auth.Data.Models;

namespace DairyDemo.Auth.Services;

public sealed class AuthService
{
    private readonly UserRepository _repo = new();
    private readonly PasswordService _pwd = new();

    private const string InvalidMsg =
        "Вы ввели неверный логин или пароль. Пожалуйста, проверьте ещё раз введённые данные";
    private const string LockedMsg =
        "Вы заблокированы. Обратитесь к администратору";
    private const string SuccessMsg =
        "Вы успешно авторизовались";

    public async Task<(bool ok, string message, User? user)> LoginAsync(
        string login, string password, bool captchaOk)
    {
        login = (login ?? "").Trim();

        var user = await _repo.GetByLoginAsync(login);
        if (user is null)
            return (false, InvalidMsg, null);

        if (user.IsLocked)
            return (false, LockedMsg, user);

        // Попытка №1/2/3: капча неверна => считаем попытку неудачной
        if (!captchaOk)
        {
            await _repo.IncrementFailedAttemptsAndLockIfNeededAsync(user.Id);
            return (false, InvalidMsg, user);
        }

        // Попытка №1/2/3: пароль неверен => считаем попытку неудачной
        if (!_pwd.Verify(password, user.PasswordHash))
        {
            await _repo.IncrementFailedAttemptsAndLockIfNeededAsync(user.Id);
            return (false, InvalidMsg, user);
        }

        // Успех: сбросить счётчик попыток
        await _repo.ResetFailedAttemptsAsync(user.Id);
        return (true, SuccessMsg, user);
    }
}