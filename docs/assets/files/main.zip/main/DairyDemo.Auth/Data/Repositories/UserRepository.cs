﻿using DairyDemo.Auth.Data.Models;
using Npgsql;

namespace DairyDemo.Auth.Data.Repositories;

public sealed class UserRepository
{
    public async Task<User?> GetByLoginAsync(string login)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
select id, login, password_hash, role, failed_attempts, is_locked
from app.users
where login = @login;
";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("login", login);

        await using var r = await cmd.ExecuteReaderAsync();
        if (!await r.ReadAsync()) return null;

        return new User
        {
            Id = r.GetInt64(0),
            Login = r.GetString(1),
            PasswordHash = r.GetString(2),
            Role = r.GetString(3),
            FailedAttempts = r.GetInt32(4),
            IsLocked = r.GetBoolean(5)
        };
    }

    public async Task<List<User>> GetAllAsync()
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
select id, login, password_hash, role, failed_attempts, is_locked
from app.users
order by id;
";
        await using var cmd = new NpgsqlCommand(sql, conn);

        var list = new List<User>();
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            list.Add(new User
            {
                Id = r.GetInt64(0),
                Login = r.GetString(1),
                PasswordHash = r.GetString(2),
                Role = r.GetString(3),
                FailedAttempts = r.GetInt32(4),
                IsLocked = r.GetBoolean(5)
            });
        }
        return list;
    }

    public async Task<bool> ExistsLoginAsync(string login)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"select 1 from app.users where login=@login limit 1;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("login", login);

        return await cmd.ExecuteScalarAsync() != null;
    }

    public async Task AddUserAsync(string login, string passwordHash, string role)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
insert into app.users(login, password_hash, role)
values (@login, @hash, @role);
";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("login", login);
        cmd.Parameters.AddWithValue("hash", passwordHash);
        cmd.Parameters.AddWithValue("role", role);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdateUserAsync(long id, string login, string role)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
update app.users
set login=@login, role=@role
where id=@id;
";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("id", id);
        cmd.Parameters.AddWithValue("login", login);
        cmd.Parameters.AddWithValue("role", role);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdatePasswordAsync(long id, string passwordHash)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"update app.users set password_hash=@hash where id=@id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("id", id);
        cmd.Parameters.AddWithValue("hash", passwordHash);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task IncrementFailedAttemptsAndLockIfNeededAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
update app.users
set failed_attempts = failed_attempts + 1,
    is_locked = case when (failed_attempts + 1) >= 3 then true else is_locked end
where id = @id;
";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("id", userId);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task ResetFailedAttemptsAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"update app.users set failed_attempts = 0 where id=@id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("id", userId);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UnlockAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"update app.users set failed_attempts=0, is_locked=false where id=@id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("id", userId);
        await cmd.ExecuteNonQueryAsync();
    }
}