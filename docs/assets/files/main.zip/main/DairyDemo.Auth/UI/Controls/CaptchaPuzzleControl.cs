﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace DairyDemo.Auth.UI.Controls;

public class CaptchaPuzzleControl : UserControl
{
    private readonly PictureBox[] _boxes = new PictureBox[4];
    private int[] _currentOrder = new int[4];
    private int? _selectedIndex = null;

    public bool IsSolved { get; private set; }

    public CaptchaPuzzleControl()
    {
        Width = 220;
        Height = 220;

        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 2,
            ColumnCount = 2
        };

        table.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        table.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

        for (int i = 0; i < 4; i++)
        {
            var pb = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.StretchImage,
                BorderStyle = BorderStyle.FixedSingle,
                Tag = i
            };

            pb.Click += OnTileClick;
            _boxes[i] = pb;
            table.Controls.Add(pb, i % 2, i / 2);
        }

        Controls.Add(table);
    }

    public void LoadFromFolder(string folderPath)
    {
        if (!Directory.Exists(folderPath))
            throw new DirectoryNotFoundException(folderPath);

        for (int i = 0; i < 4; i++)
        {
            var path = Path.Combine(folderPath, $"{i + 1}.png");
            if (!File.Exists(path))
                throw new FileNotFoundException(path);

            _boxes[i].Image = Image.FromFile(path);
        }

        Shuffle();
    }

    public void Shuffle()
    {
        var rnd = new Random();
        _currentOrder = Enumerable.Range(0, 4)
            .OrderBy(_ => rnd.Next())
            .ToArray();

        ApplyOrder();
        CheckSolved();
    }

    private void ApplyOrder()
    {
        for (int i = 0; i < 4; i++)
        {
            _boxes[i].Image = Image.FromFile(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                    "Assets", "captcha", $"{_currentOrder[i] + 1}.png")
            );

            _boxes[i].BorderStyle = BorderStyle.FixedSingle;
        }

        _selectedIndex = null;
    }

    private void OnTileClick(object? sender, EventArgs e)
    {
        if (sender is not PictureBox pb) return;

        int index = Array.IndexOf(_boxes, pb);

        if (_selectedIndex == null)
        {
            _selectedIndex = index;
            pb.BorderStyle = BorderStyle.Fixed3D;
            return;
        }

        if (_selectedIndex == index)
        {
            pb.BorderStyle = BorderStyle.FixedSingle;
            _selectedIndex = null;
            return;
        }

        // swap
        (_currentOrder[_selectedIndex.Value], _currentOrder[index]) =
            (_currentOrder[index], _currentOrder[_selectedIndex.Value]);

        ApplyOrder();
        CheckSolved();
    }

    private void CheckSolved()
    {
        IsSolved = _currentOrder.SequenceEqual(new[] { 0, 1, 2, 3 });
    }
}
