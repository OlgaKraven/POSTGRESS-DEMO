using DairyDemo.Auth.UI.Forms;

namespace DairyDemo.Auth;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        //var hash = BCrypt.Net.BCrypt.HashPassword("admin");

        //var tb = new TextBox
        //{
        //    Multiline = true,
        //    ReadOnly = true,
        //    Dock = DockStyle.Fill,
        //    Text = hash
        //};

        //var form = new Form
        //{
        //    Text = "��� ������",
        //    Width = 600,
        //    Height = 200
        //};

        //form.Controls.Add(tb);
        //form.ShowDialog();

        ApplicationConfiguration.Initialize();
        Application.Run(new LoginForm());
    }
}