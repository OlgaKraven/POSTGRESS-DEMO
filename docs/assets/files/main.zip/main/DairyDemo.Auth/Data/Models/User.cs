﻿namespace DairyDemo.Auth.Data.Models;

public sealed class User
{
    public long Id { get; init; }
    public string Login { get; init; } = "";
    public string PasswordHash { get; init; } = "";
    public string Role { get; init; } = "user"; // admin | user
    public int FailedAttempts { get; init; }
    public bool IsLocked { get; init; }
}