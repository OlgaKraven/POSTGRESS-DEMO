﻿using DairyDemo.Auth.Data.Models;
using DairyDemo.Auth.Data.Repositories;
using DairyDemo.Auth.Services;

namespace DairyDemo.Auth.UI.Forms;

public sealed partial class AdminForm : Form
{
    private readonly User _admin;
    private readonly UserRepository _repo = new();
    private readonly PasswordService _pwd = new();

    private readonly DataGridView _dgv = new();

    private readonly TextBox _tbLogin = new();
    private readonly ComboBox _cbRole = new();
    private readonly TextBox _tbNewPassword = new();

    private readonly Button _btnAdd = new();
    private readonly Button _btnUpdate = new();
    private readonly Button _btnResetPwd = new();
    private readonly Button _btnUnlock = new();

    private long? _selectedUserId = null;

    public AdminForm(User admin)
    {
        _admin = admin;

        Text = $"Администратор: {_admin.Login}";
        Width = 860;
        Height = 520;
        StartPosition = FormStartPosition.CenterScreen;

        // Таблица
        _dgv.SetBounds(20, 20, 800, 240);
        _dgv.ReadOnly = true;
        _dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _dgv.MultiSelect = false;
        _dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _dgv.CellClick += Dgv_CellClick;

        // Поля
        var lblLogin = new Label { Text = "Логин", Left = 20, Top = 280, AutoSize = true };
        _tbLogin.SetBounds(20, 305, 240, 28);

        var lblRole = new Label { Text = "Роль", Left = 280, Top = 280, AutoSize = true };
        _cbRole.SetBounds(280, 305, 160, 28);
        _cbRole.DropDownStyle = ComboBoxStyle.DropDownList;
        _cbRole.Items.AddRange(new[] { "admin", "user" });
        _cbRole.SelectedIndex = 1;

        var lblPwd = new Label { Text = "Новый пароль (для сброса)", Left = 460, Top = 280, AutoSize = true };
        _tbNewPassword.SetBounds(460, 305, 220, 28);
        _tbNewPassword.UseSystemPasswordChar = true;

        // Кнопки
        _btnAdd.Text = "Добавить";
        _btnAdd.SetBounds(20, 350, 160, 36);
        _btnAdd.Click += BtnAdd_Click;

        _btnUpdate.Text = "Сохранить изменения";
        _btnUpdate.SetBounds(200, 350, 240, 36);
        _btnUpdate.Click += BtnUpdate_Click;

        _btnResetPwd.Text = "Сбросить пароль";
        _btnResetPwd.SetBounds(460, 350, 220, 36);
        _btnResetPwd.Click += BtnResetPwd_Click;

        _btnUnlock.Text = "Снять блокировку";
        _btnUnlock.SetBounds(700, 350, 120, 36);
        _btnUnlock.Click += BtnUnlock_Click;

        Controls.AddRange(new Control[]
        {
            _dgv,
            lblLogin, _tbLogin,
            lblRole, _cbRole,
            lblPwd, _tbNewPassword,
            _btnAdd, _btnUpdate, _btnResetPwd, _btnUnlock
        });

        Shown += async (_, __) => await ReloadUsersAsync();
    }

    private async Task ReloadUsersAsync()
    {
        var users = await _repo.GetAllAsync();

        // Чтобы в таблице не показывать хэш как “важную инфу”, можно спрятать колонку
        _dgv.DataSource = users.Select(u => new
        {
            u.Id,
            u.Login,
            u.Role,
            u.FailedAttempts,
            u.IsLocked
        }).ToList();
    }

    private void Dgv_CellClick(object? sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0) return;

        var row = _dgv.Rows[e.RowIndex];
        _selectedUserId = Convert.ToInt64(row.Cells["Id"].Value);

        _tbLogin.Text = Convert.ToString(row.Cells["Login"].Value) ?? "";
        _cbRole.SelectedItem = Convert.ToString(row.Cells["Role"].Value) ?? "user";
        _tbNewPassword.Text = "";
    }

    private async void BtnAdd_Click(object? sender, EventArgs e)
    {
        var login = _tbLogin.Text.Trim();
        var role = Convert.ToString(_cbRole.SelectedItem) ?? "user";

        if (string.IsNullOrWhiteSpace(login))
        {
            MessageBox.Show("Укажите логин.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        // Пароль обязателен при создании
        if (string.IsNullOrWhiteSpace(_tbNewPassword.Text))
        {
            MessageBox.Show("Укажите пароль для нового пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (await _repo.ExistsLoginAsync(login))
        {
            MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        var hash = _pwd.HashPassword(_tbNewPassword.Text);
        await _repo.AddUserAsync(login, hash, role);

        MessageBox.Show("Пользователь добавлен.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
        await ReloadUsersAsync();
    }

    private async void BtnUpdate_Click(object? sender, EventArgs e)
    {
        if (_selectedUserId is null)
        {
            MessageBox.Show("Выберите пользователя в таблице.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var login = _tbLogin.Text.Trim();
        var role = Convert.ToString(_cbRole.SelectedItem) ?? "user";

        if (string.IsNullOrWhiteSpace(login))
        {
            MessageBox.Show("Логин не может быть пустым.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        await _repo.UpdateUserAsync(_selectedUserId.Value, login, role);
        MessageBox.Show("Изменения сохранены.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
        await ReloadUsersAsync();
    }

    private async void BtnResetPwd_Click(object? sender, EventArgs e)
    {
        if (_selectedUserId is null)
        {
            MessageBox.Show("Выберите пользователя в таблице.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (string.IsNullOrWhiteSpace(_tbNewPassword.Text))
        {
            MessageBox.Show("Введите новый пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var hash = _pwd.HashPassword(_tbNewPassword.Text);
        await _repo.UpdatePasswordAsync(_selectedUserId.Value, hash);

        MessageBox.Show("Пароль обновлён.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
        _tbNewPassword.Text = "";
    }

    private async void BtnUnlock_Click(object? sender, EventArgs e)
    {
        if (_selectedUserId is null)
        {
            MessageBox.Show("Выберите пользователя в таблице.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        await _repo.UnlockAsync(_selectedUserId.Value);
        MessageBox.Show("Блокировка снята.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
        await ReloadUsersAsync();
    }
}