﻿using DairyDemo.Auth.Data.Models;

namespace DairyDemo.Auth.UI.Forms;

public sealed partial class UserForm : Form
{
    private readonly User _user;

    public UserForm(User user)
    {
        _user = user;

        Text = "Рабочий стол пользователя";
        Width = 420;
        Height = 220;
        StartPosition = FormStartPosition.CenterScreen;

        var lbl = new Label
        {
            Text = $"Вы вошли как: {_user.Login}\nРоль: {_user.Role}",
            AutoSize = true,
            Left = 20,
            Top = 20
        };

        var btnExit = new Button
        {
            Text = "Выход",
            Left = 20,
            Top = 90,
            Width = 120,
            Height = 36
        };
        btnExit.Click += (_, __) => Close();

        Controls.Add(lbl);
        Controls.Add(btnExit);
    }
}