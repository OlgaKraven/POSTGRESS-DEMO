﻿using Npgsql;

namespace DairyDemo.Auth.Data;

public static class Db
{
    // ВАЖНО:
    // Database — имя вашей БД в PostgreSQL
    // Username / Password — учётные данные PostgreSQL
    // Search Path = схема (app или public)
    public static string ConnectionString =
        "Host=localhost;Port=5432;Database=dairy_demo ;Username=postgres;Password=root;Search Path=app";

    public static NpgsqlConnection CreateConnection()
        => new NpgsqlConnection(ConnectionString);
}